import Card from 'react-bootstrap/Card';
import React from 'react'
function Footer() {
  return (
    <Card>
      <Card.Body>This is some text within a card body.</Card.Body>
    </Card>
  );
}

export default Footer;