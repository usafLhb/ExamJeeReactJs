import Card from 'react-bootstrap/Card'; 
import React, { useState, useEffect } from 'react';
import { Container,Navbar,Row ,Button,Col,Table,FormControl,ListGroup} from 'react-bootstrap'
import Header from './Header';
function Historik() {

  const [film, setfilm] = useState(); 

  const getApiData = async () => {
    const response = await fetch(
      "http://localhost:9090/ticket"
    ).then((response) => response.json());
  
    // update the state
    console.log(response);
    setfilm(response);

    
  }

  useEffect(() => {
    getApiData();
  }, []);




  return (
    <div>
      <Header/>
       <Container>
  <Row style={{margin: "auto"}}>
       {
    film?.map((film) => (
      <Col md={4}> 
  <Card style={{ width: '18rem' }}>
    <Card.Body>
      <Card.Title>{film.movie.titre}</Card.Title>
      <Card.Subtitle className="mb-2 text-muted">{film.prix}</Card.Subtitle>
      <Card.Text>
      {film.movie.description}
      </Card.Text> 
      <Card.Subtitle className="mb-2 text-muted">{film.createDate}</Card.Subtitle>
    </Card.Body>
  </Card>
  </Col>
  ))}
  </Row></Container>
  </div>
  );
}

export default Historik;