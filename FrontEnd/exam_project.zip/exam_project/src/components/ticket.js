 
import Button from 'react-bootstrap/Button';
import { Navbar,Form,Card ,Row,Col,InputGroup,FormControl,ListGroup} from 'react-bootstrap'
import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useState, useEffect } from 'react';

function Ticket() {

  
    const [titre, settitre] = useState("null");
    const [Categorie, setCategorie] = useState();
    const [description, setdescription] = useState();
    const [duree, setduree] = useState();
    const [prix, setprix] = useState();
    const [cat, setcat] = useState();
    const [film, setfilm] = useState();

    const getApiData = async () => {
        //alert(titre);
        const response = await fetch(
          "http://localhost:9090/film/titre/"+titre
        ).then((response) => response.json());
       
        console.log(response.titre);
        settitre(response.titre);
        setduree(response.duree);
        setdescription(response.description);
        setCategorie(response.categorie.nom); 
        setprix(response.prix)
        setfilm(response);
        
      };


      const handleSubmit = e => {
        e.preventDefault();
     
        const requestOptions = {
          method: "POST",
          headers: { "Content-Type": "application/json" }, 
          body: JSON.stringify({ 
         "nomClient":"emsi" ,
          "prix":prix,
          "codePayement": randomNumberInRange})
        };
        fetch("http://localhost:9090/ticket/"+film.id, requestOptions)
          .then(response => response.json())
          .then(res => console.log(res));
      };

      function randomNumberInRange() {

       let newDate = new Date()
let date = newDate.getDate();
let month = newDate.getMonth() + 1;
let year = newDate.getFullYear();

        return Math.floor(Math.random() * (1000 - 1 + 1)+date*7+month*14+year*2) + 20;
      }

  return (
    <div className="App">
   <input type="text"  onChange={(e) => settitre(e.target.value)}></input>
 
   <input type="button" value="Search" onClick={getApiData} ></input>
   <br/>
   
    
      <br />
    
      <Row>
        <Form.Label column lg={2}>
        titre
        </Form.Label>
        <Col>
          <Form.Control type="text"  value={titre} />
        </Col>
      </Row>
      <Row>
        <Form.Label column lg={2}>
        description
        </Form.Label>
        <Col>
          <Form.Control type="text"  value={description} />
        </Col>
      </Row>
      <Row>
        <Form.Label column lg={2}>
        duree
        </Form.Label>
        <Col>
          <Form.Control type="text"  value={duree}/>
        </Col>
      </Row>
      <Row>
        <Form.Label column lg={2}>
        categorie
        </Form.Label>
        <Col>
          <Form.Control type="text"  value={Categorie} />
        </Col>
      </Row>
      <Row>
        <Form.Label column lg={2}>
        Prix
        </Form.Label>
        <Col>
          <Form.Control type="text"  value={prix} />
        </Col>
      </Row>
      <br />
     
    <button  onClick={handleSubmit} > prendre ticket pour ce film</button>
    </div>  
  );
}

export default Ticket;