
import { Button,FloatingLabel,Form ,Row,Col,Table,FormControl,ListGroup} from 'react-bootstrap'
import React, { useState, useEffect } from 'react';
import Header from './Header';
function Postmovie() {
 
    const [Categorie, setCategorie] = useState();
    const [titre, settitre] = useState();
    const [description, setdescription] = useState();
    const [duree, setduree] = useState();
    const [prix, setprix] = useState();
    
    const [cat, setcat] = useState();


 

    const getApiData = async () => {
        const response = await fetch(
          "http://localhost:9090/categorie"
        ).then((response) => response.json());
      
        // update the state
        console.log(response);
        setCategorie(response);

        
      };

      useEffect(() => {
        getApiData();
      }, []);
 

      function test(){ 
        alert(titre);
        alert(description);
        alert(duree);
        alert(Categorie);

      }

      const handleSubmit = e => {
        e.preventDefault();
     
        const requestOptions = {
          method: "POST",
          headers: { "Content-Type": "application/json" }, 
          body: JSON.stringify({ 
         "titre":titre ,
          "description":description,
          "duree": duree,
          "prix":prix
        })
        };
        fetch("http://localhost:9090/film/2", requestOptions)
          .then(response => response.json())
          .then(res => console.log(res));
      };
   






   
   




    return (
        <div>
                <Header/>
<Form>
  <Form.Group className="mb-3" controlId="exampleForm.ControlInput1"> 
    <Form.Control type="text" placeholder="Titre"  onChange={(e) => settitre(e.target.value)}/>
  </Form.Group>
  <Form.Group className="mb-3" controlId="exampleForm.ControlInput1"> 
    <Form.Control type="text" placeholder="Descritption"  onChange={(e) => setdescription(e.target.value)} />
  </Form.Group>
  <Form.Group className="mb-3" controlId="exampleForm.ControlInput1"> 
    <Form.Control type="text" placeholder="Duree"  onChange={(e) => setduree(e.target.value)} />
  </Form.Group>

  <Form.Group className="mb-3" controlId="exampleForm.ControlInput1"> 
    <Form.Control type="text" placeholder="Prix pour ticket"  onChange={(e) => setprix(e.target.value)} />
  </Form.Group>


  <FloatingLabel controlId="floatingSelect" label="Choose  which  categorie">
      <Form.Select aria-label="">
        <option></option>
        {
    Categorie?.map((cat) => (
        <option  onClick={(e) => setCategorie(cat.id)}  value={cat.id}>{cat.nom}</option>
    ))}
        
      </Form.Select>
    </FloatingLabel>
    <Button variant="primary" type="submit"  onClick={handleSubmit}>
        Submit
      </Button>

    


      
</Form>
</div>
  );
}

export default Postmovie;