 
import { Container,Navbar,Card ,Button,Col,Table,FormControl,ListGroup,Carousel} from 'react-bootstrap'
import React, { useState, useEffect } from 'react';
import {useNavigate,  Route, Routes,Link} from 'react-router-dom'; 
import Sign from './Sign';  
import HeaderClient from './HeaderClient'; 
import Ticket from './ticket'; 
import avenger from '../asset/avenger.jpg';
import batman from '../asset/batman.jpg';
import venom from '../asset/venom.jpg';
import Aladdin from '../asset/Aladdin.webp';
import rampage from '../asset/rampage.webp'; 

 
function Getmovieclient() {
    const [Users, fetchUsers] = useState([])
    const [status, setState] = useState([])
    

    const [users, setUsers] = useState();
    const getApiData = async () => {
        const response = await fetch(
          "http://localhost:9090/film"
        ).then((response) => response.json());
      
        // update the state
        console.log(response);
        setUsers(response);

        
      };

      useEffect(() => {
        getApiData();
      }, []);
 

 
 

    
  
 


  return (
    <div>
      <HeaderClient/>


      <Carousel>
      <Carousel.Item>
       

    <img src={avenger}  className="d-block w-100" 
            /> 


        <Carousel.Caption>
          <h3>Avenger</h3>
          <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
      <img  
// style={{    float: "right" ,margin: "10px 0 0 0px"}}
              src={Aladdin}  
             
              className="d-block w-100" 
            />

        <Carousel.Caption>
          <h3>Aladdin</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
      <img   
              src={rampage}  
             
              className="d-block w-100" 
            /> 

        <Carousel.Caption>
          <h3>rampage</h3>
          <p>
            Praesent commodo cursus magna, vel scelerisque nisl consectetur.
          </p>
        </Carousel.Caption>
      </Carousel.Item>


      <Carousel.Item>
      <img   
              src={batman}  
             
              className="d-block w-100" 
            /> 

        <Carousel.Caption>
          <h3>Batman</h3>
          <p>
            Praesent commodo cursus magna, vel scelerisque nisl consectetur.
          </p>
        </Carousel.Caption>
      </Carousel.Item>



      <Carousel.Item>
      <img   
              src={venom}  
             
              className="d-block w-100" 
            /> 

        <Carousel.Caption>
          <h3>Venom</h3>
          <p>
            Praesent commodo cursus magna, vel scelerisque nisl consectetur.
          </p>
        </Carousel.Caption>
      </Carousel.Item>

    </Carousel>


    <Table striped bordered hover size="sm">
      <thead>
        <tr>
          <th>#</th>
          <th>Titre</th>
          <th>Description</th>
          <th>duree</th>
          <th>Categorie</th> 
        </tr>
      </thead>
      <tbody>
      {
    users?.map((film) => (
      
      <tr>
        <td>{film.id}</td>
        <td>{film.titre}</td>
        <td>{film.description}</td>    
        <td>{film.duree}</td> 
        <td>{film.categorie.nom}</td>  
      </tr>
  ))}
       
      </tbody>
    </Table>
    
    <Ticket/>
 

    </div>

  
    
  );
}

export default Getmovieclient;