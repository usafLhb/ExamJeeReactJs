import React, { useState, useEffect } from 'react';
import Button from 'react-bootstrap/Button';
import { Container,Navbar,Form,Card ,Row,Col,InputGroup,FormControl,ListGroup} from 'react-bootstrap'
import 'bootstrap/dist/css/bootstrap.min.css';
import {Routes, Route, useNavigate} from 'react-router-dom';
import Getmovie from './Getmovie';
import Postmovie from './Postmovie';

function Sign() {


    const [email, setemail] = useState();     
    const [password, setpassword] = useState(); 


    const handleSubmit = e => {
        e.preventDefault();
     
      if(email=="user"){
        navigate('/Getmovieclient');
      }
      else if(email=="admin"){
        navigate('/Getmovie');
        // alert("admin");
      }else{alert("error");}
      };


      const navigate = useNavigate();
 

   



  return (
    <div className="App"  style={{ backgroundColor: "#d6dde3",padding:"50px 20px" }}>
        <Container style={{ display: "flex",
          justifyContent: "center",
          alignItems: "center"}}>
            <Row>
            <h1>Login In</h1>

            <Card>
      <Form>
  <Form.Group className="mb-3" controlId="formBasicEmail">
    <Form.Label>Email address</Form.Label>
    <Form.Control type="email" placeholder="Enter email"   onChange={(e) => setemail(e.target.value)}/>
    <Form.Text className="text-muted">
      We'll never share your email with anyone else.
    </Form.Text>
  </Form.Group>

  <Form.Group className="mb-3" controlId="formBasicPassword">
    <Form.Label>Password</Form.Label>
    <Form.Control type="password" placeholder="Password"  onChange={(e) => setpassword(e.target.value)} />
  </Form.Group>
  <Form.Group className="mb-3" controlId="formBasicCheckbox">
    <Form.Check type="checkbox" label="Check me out" />
  </Form.Group>
  <Button variant="primary" type="submit"  onClick={handleSubmit}>
    Submit
  </Button>
</Form>
</Card>
</Row>
 

      
</Container>
    </div>
  );
}

export default Sign;