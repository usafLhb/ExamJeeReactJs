 
import { Container,Navbar,Card ,Button,Col,Table,FormControl,ListGroup} from 'react-bootstrap'
import React, { useState, useEffect } from 'react';
import Header from './Header';
function Getmovie() {
    const [Users, fetchUsers] = useState([])
    const [status, setState] = useState([])
    

    const [users, setUsers] = useState();
    const getApiData = async () => {
        const response = await fetch(
          "http://localhost:9090/film"
        ).then((response) => response.json());
      
        // update the state
        console.log(response);
        setUsers(response);

        
      };

      useEffect(() => {
        getApiData();
      }, []);
 

 
 

    
  




  return (
    <div>
        <Header/>
    <Table striped bordered hover size="sm">
      <thead>
        <tr>
          <th>#</th>
          <th>Titre</th>
          <th>Description</th>
          <th>duree</th>
          <th>Categorie</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
      {
    users?.map((film) => (
      
      <tr>
        <td>{film.id}</td>
        <td>{film.titre}</td>
        <td>{film.description}</td>    
        <td>{film.duree}</td> 
        <td>{film.categorie.nom}</td> 
        <td>  <Button onClick={()=>{  fetch('http://localhost:9090/film/'+film.id, { method: 'DELETE' })
        .then(() => this.setState({ status: 'Delete successful' }));}}>Delete</Button>  </td> 
      </tr>
  ))}
       
      </tbody>
    </Table>
    

  
    </div>
  );
}

export default Getmovie;