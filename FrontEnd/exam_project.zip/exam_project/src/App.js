import logo from './logo.svg';
import './App.css';
import Sign from './components/Sign';  
import Footer from './components/Footer';  
import Header from './components/Header';  
import Getmovie from './components/Getmovie';  
import Postmovie from './components/Postmovie';  
import Getmovieclient from './components/Getmovieclient';  
import Ticket from './components/ticket';
import Historik from './components/Historik'; 
import Historikuser from './components/Historikuser'; 


import {
  BrowserRouter as Router,
  Switch,
  Route,
  Routes,
  Link,
  BrowserRouter,
  HashRouter
} from "react-router-dom";


import { Container} from 'react-bootstrap'

function App() {
  return (
    <div className="App">

<div>
     <Container>
        {/* <Header /> */}
        <BrowserRouter>
        
        <Routes>
        <Route index    element={<Sign />} />
          <Route path="/Getmovie" element={<Getmovie/>} />
          <Route path="/Post" element={<Postmovie />} />
          <Route path="/Historik" element={<Historik />} />
          
          {/* User */}

          <Route path="/Getmovieclient" element={<Getmovieclient />} />
          <Route path="/HistoriqueUser" element={<Historikuser />} />
        </Routes>

        {/* <Sign /> */}
        </BrowserRouter>
        {/* <Getmovie/>
        <Postmovie/>
        <Getmovieclient/>
        <Ticket/>
        <Historik/>
        <Footer /> */}
        </Container>
      </div>

 
      
    
    </div>
  );
}

export default App;
